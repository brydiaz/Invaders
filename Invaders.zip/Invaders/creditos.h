#ifndef CREDITOS_H
#define CREDITOS_H

#include <QMainWindow>

namespace Ui {
class creditos;
}

class creditos : public QMainWindow
{
    Q_OBJECT

public:
    explicit creditos(QWidget *parent = nullptr);
    ~creditos();

private slots:
    void on_pushButton_clicked();

private:
    Ui::creditos *ui;
};

#endif // CREDITOS_H
