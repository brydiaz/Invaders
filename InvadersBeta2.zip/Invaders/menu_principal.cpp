#include "menu_principal.h"
#include "ui_menu_principal.h"
#import "juegoprincipal.h"
#import "creditos.h"

menu_principal::menu_principal(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::menu_principal)
{
    ui->setupUi(this);
}

menu_principal::~menu_principal()
{
    delete ui;
}

void menu_principal::on_pushButton_clicked()
{
    close();
    JuegoPrincipal *jp = new JuegoPrincipal();
    jp->show();
}

void menu_principal::on_pushButton_2_clicked()
{
    close();
    creditos *cr = new creditos();
    cr->show();
}
