#include "creditos.h"
#include "ui_creditos.h"
#include "menu_principal.h"

creditos::creditos(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::creditos)
{
    ui->setupUi(this);
}

creditos::~creditos()
{
    delete ui;
}

void creditos::on_pushButton_clicked()
{
    close();
    menu_principal *mp = new menu_principal();
    mp->show();
}
